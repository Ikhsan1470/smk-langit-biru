<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "file";
$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if (!$conn) {
    error_log("Failed to connect to MySQL: " . mysqli_error($conn));
    die('Internal server error');
}

$dbopen = mysqli_select_db($conn, $dbname);
if (!$dbopen) {
    error_log("Database selection failed: " . mysqli_error($conn));
    die('Internal server error');
}
?>
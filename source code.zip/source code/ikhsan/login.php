<!DOCTYPE html>
<html>
<head>
  <title>SMK Langit Biru Negeri</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-widht, initial-scale=1.0">
  </script>
</head>
<body>
<div class="container">
  <div class="header">
    <img src="img/jepang/logo_sakura.png" width="9%" style="float: left;">
    <div class="container" align="center">
      <h4>SMK Langit Biru Negeri</h4>
      <h5>Jl. Raya Majalaya - Rancaekek Desa No.5, Bojongloa, Kec. Rancaekek, Bandung, Jawa Barat 40394</h5>
      <h6>No.Telp: 089656428386</h6>
    </div>
  </div>
</div>

<div class="container">
  <div class="col-md-3 col-xs-12 menu-sidebar">
    <hr>
    <?php
      echo date('h : i : s'); 
      echo "</br>";
      echo date('l, d-M-Y');
    ?>
    <hr>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="login.php">Login</li><a>
    </ul>

    <h5 align="center">About</h5>
    <p><strong>SMK Langit Biru Negeri</strong>adalah sekolah berbasis seperti
      sekolah di Jepang yang dimana sekolah ini mengikuti peraturan-peraturan yang
      ada di sekolah di Jepang, dimana para murid dibekali dengan pendidikan yang bermutu,
      berkualitas
    </p>
  </div>
</div>

<div class="container">
  <div class="content">
    <title>Form Login</title>
    <div align='center'>
      <form action="proseslogin.php" method="post">
      <h1>Masuk</h1>
      <table>
      <tbody>
      <tr>
        <td>Username</td>
        <td> : <input name="username" type="text"></td>
      </tr>
      <tr>
        <td>Password</td>
        <td> : <input name="password" type="password"></td>
      </tr>
      <tr>
        <td colspan="2" align="right"><input value="Login" type="submit"> <input value="Batal" type="reset"></td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td colspan="2" align="center">Belum Punya akun ? <a href="daftar.php"><b>Daftar</b></a></td>
      </tr>
      </tbody>
      </table>
      </form>
    </div>
  </div>
</div>

<div class="container">
  <div class="footer">
    <div class="container" align="center">
      <h4>Copyright &copy; 2019</h4>
      <p>mikhsanassidiq54@gmail.com</p>
      <p>Web ini dibuat oleh Muhamad Ikhsan Assidiq</p>
    </div>
  </div>
</div>

</body>
</html>
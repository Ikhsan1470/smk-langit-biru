<?php
include ('config.php');
include ('action_upload.php');
?>
<!DOCTYPE html>
<html>
<head>
  <title>Pendaftaran</title>
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-widht, initial-scale=1.0">
  <script type="text/javascript">
    function pemberithuan(){
      alert("Pendaftaran Berhasil");
    }
  </script>
</head>
<body>
<div class="container">
  <div class="header">
    <img src="img/jepang/logo_sakura.png" width="9%" style="float: left;">
    <div class="container" align="center">
      <h4>SMK Langit Biru Negeri</h4>
      <h5>Jl. Raya Majalaya - Rancaekek Desa No.5, Bojongloa, Kec. Rancaekek, Bandung, Jawa Barat 40394</h5>
      <h6>No.Telp: 089656428386</h6>
    </div>
  </div>
</div>

<div class="container">
  <div class="col-md-3 col-xs-12 menu-sidebar">
    <hr>
    <?php
      echo date('h : i : s'); 
      echo "</br>";
      echo date('l, d-M-Y');
    ?>
    <hr>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="profil.php">Profil</a></li>
      <li><a href="galeri.php">Galeri</a></li>
      <li><a href="login.php">Login</li><a>    
      <li><a href="upload_file.php">Upload File</a></li>
      <li><a href="logout.php">LOGOUT</a></li>
    </ul>

    <h5 align="center">About</h5>
    <p><strong>SMK Langit Biru Negeri</strong>adalah sekolah berbasis seperti
      sekolah di Jepang yang dimana sekolah ini mengikuti peraturan-peraturan yang
      ada di sekolah di Jepang, dimana para murid dibekali dengan pendidikan yang bermutu,
      berkualitas
    </p>
  </div>
</div>

<div class="container">
  <div class="content">
    <div align='center'>
      <form action="prosesdaftar.php" method="post">
      <table>      
      <tr>
        <td colspan="2" align="center"><h1>Daftar Baru</h1></td>
      </tr>
      <tr>
        <td>Nama</td>
        <td> : <input name="username" type="text"></td>
      </tr>
      <tr>
        <td>Password</td>
        <td> : <input type="password" name="password"></td>
      </tr>
      <tr>
        <td>Alamat</td>
        <td> : <input name="alamat" type="text"></td>
      </tr>
      <tr>
        <td>Jenis Kelamin</td>
        <td> : <input type="radio" name="jenis_kelamin" value="Laki-laki">Laki-laki</td>
        <td><input type="radio" name="jenis_kelamin" value="Perempuan">Perempuan</td>
      </tr>
      <tr>
        <td>Jurusan</td>
        <td> : </td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TP">TP</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TKR">TKR</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="TSM">TSM</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="RPL">RPL</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="DKV">DKV</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="radio" name="jurusan" value="PS">PS</td>
      </tr>
      <tr>
        <td>Hobi</td>
        <td> : </td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Basket">Basket</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Futsal">Futsal</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Renang">Renang</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Bersepeda">Bersepeda</td>
      </tr>
      <tr>
        <td></td>
        <td><input type="checkbox" name="hobi" value="Berwisata">Berwisata</td>
      </tr>
      <tr>
        <td colspan="2" align="right"><input value="Daftar" type="submit" onclick="pemberithuan()"> <input value="Batal" type="reset"></td>
      </tr>
      <tr>
        <td colspan="2" align="center">Sudah Punya akun ? <a href="login.php"><b>Login</b></a></td>
      </tr>
      </table>
      </form>
    </div>
  </div>
</div>

<div class="container">
  <div class="footer">
    <div class="container" align="center">
      <h4>Copyright &copy; 2019</h4>
      <p>mikhsanassidiq54@gmail.com</p>
      <p>Web ini dibuat oleh Muhamad Ikhsan Assidiq</p>
    </div>
  </div>
</div>

</body>
</html>
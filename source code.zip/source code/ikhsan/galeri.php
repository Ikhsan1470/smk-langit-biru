<!DOCTYPE html>
<html>
<head>
	<title>Galeri</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-widht, initial-scale=1.0">
	<script language="javascript"> //Menyatakan javascript
    var pesan = "Dilarang masuk selain petugas!"; //Membuat variabel pesan dengan nilai string
    function warning() //membuat fungsi warning
    {
      alert(pesan);
    }
    function password() //membuat fungsi password
    {
      var pass = prompt ("Masukkan Password"); //membuat textbox password
      if (pass != 'petugas') { //membuat percabangan dengan kondisi password
        alert(gagal);
      }else{
        alert(sukses);
      }
    }
  </script>
</head>
<body onload="warning();">
	<!-- Header -->
<div class="container">
	<div class="header">
		<img src="img/jepang/logo_sakura.png" width="9%" style="float: left;">
		<div class="container" align="center">
			<h4>SMK Langit Biru Negeri</h4>
			<h5>Jl. Raya Majalaya - Rancaekek Desa No.5, Bojongloa, Kec. Rancaekek, Bandung, Jawa Barat 40394</h5>
			<h6>No.Telp: 089656428386</h6>
		</div>
	</div>
</div>

	<!--Content-->
<div class="container">
	<div class="menu-sidebar">
		<hr>
		<?php
			echo date('h : i : s');
			echo "</br>";
			echo date('l, d-M-Y');
		?>
		<hr>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="profil.php">Profil</a></li>
			<li><a href="galeri.php">Galeri</a></li>
			<li><a href="upload_file.php">Upload File</a></li>
			<li><a href="login.php">Login</li><a>
			<li><a href="logout.php">LOGOUT</a></li>
		</ul>
		<h5>About</h5>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nullass.</p>
	</div>
</div>

	<!--Galeri-->
<div class="container">
	<div class="content">
		<p><b>TEMPAT RAHASIA</b></p>
    <p>Sekali lagi saya tegaskan jangan memasuki area ini selain petugas. BERBAHAYA!!!</p>
    <a href="javascript: password();">Masuk =></a>
		<div class="container" align="center">
			<div class="galeri">
		        <img src="img/jepang/jp1.jpg">
		        <img src="img/jepang/jp3.jpg">
		        <img src="img/jepang/jp4.jpg">
		        <img src="img/jepang/jp6.jpg">
		        <img src="img/jepang/jp7.png">
		        <img src="img/jepang/jp8.jpg">
		        <img src="img/jepang/jp10.jpg">
		        <img src="img/jepang/jp11.jpg">
		        <img src="img/jepang/jp12.jpg">
		    </div>
	    </div>
	</div>
</div>

	<!--Footer-->
<div class="container">
	<div class="footer">
		<div class="container" align="center">
			<h4>Copyright &copy; 2019</h4>
			<p>mikhsanassidiq54@gmail.com</p>
			<p>Web ini dibuat oleh Muhamad Ikhsan Assidiq</p>
		</div>
	</div>
</div>

<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap.js"></script>

</body>
</html>
<?php
include ('koneksi.php');
include ('action_upload.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>SMK Langit Biru Negeri</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-widht, initial-scale=1.0">
</head>
<body>
<div class="container">
	<div class="header">
		<img src="img/jepang/logo_sakura.png" width="9%" style="float: left;">
		<div class="container" align="center">
			<h4>SMK Langit Biru Negeri</h4>
			<h5>Jl. Raya Majalaya - Rancaekek Desa No.5, Bojongloa, Kec. Rancaekek, Bandung, Jawa Barat 40394</h5>
			<h6>No.Telp: 089656428386</h6>
		</div>
	</div>
</div>

<div class="container">
	<div class="col-md-3 col-xs-12 menu-sidebar">
		<hr>
		<?php
			echo date('h : i : s a');	
			echo "</br>";
			echo date('l, d-M-Y');
			?>
		<hr>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="profil.php">Profil</a></li>
			<li><a href="galeri.php">Galeri</a></li>
			<li><a href="upload_file.php">Upload File</a></li>
			<li><a href="login.php">Login</li><a>
			<li><a href="logout.php">LOGOUT</a></li>
		</ul>

		<h5 align="center">About</h5>
		<p><strong>SMK Langit Biru Negeri </strong>adalah sekolah berbasis seperti
			sekolah di Jepang yang dimana sekolah ini mengikuti peraturan-peraturan yang
			ada di sekolah di Jepang,
		</p>
	</div>
</div>

<div class="container">
  <div class="content">
    <form method="post" enctype="multipart/form-data" action="">
      <table align="center">
        <tr>
          <td colspan="2" height="25" class="title">Form Upload File</td>
        </tr>
        <tr>
          <td width="100">File</td>
          <td><input type="file" name="data_upload"/></td>
        </tr>
        <tr>
          <td width="100" valign="top">Keterangan</td>
          <td><textarea name="keterangan" cols="30" rows="3"></textarea></td>
        </tr>
        <tr>
          <td></td>
          <td><input type="submit" name="btnUpload" value="Upload"/></td>
        </tr>
      </table>
    </form>
  </div>
</div>

<div class="container">
	<div class="footer">
		<div class="container" align="center">
			<h4>Copyright &copy; 2019</h4>
			<p>mikhsanassidiq54@gmail.com</p>
			<p>Web ini dibuat oleh Muhamad Ikhsan Assidiq</p>
		</div>
	</div>
</div>

</body>
</html>
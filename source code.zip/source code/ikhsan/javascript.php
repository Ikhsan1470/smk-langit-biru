<!DOCTYPE html>
<html>
<head>
	<title>SMK Langit Biru Negeri</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-widht, initial-scale=1.0">
	<script type="text/javascript">
			function uppercase(){
				var textcontrol = document.getElementById('txtnama');

			}
			function lowercase(){
				var text = document.getElementById('txtnama');
			}
		</script>
</head>
<body>
<div class="container">
	<div class="header">
		<img src="img/jepang/logo_sakura.png" width="9%" style="float: left;">
		<div class="container" align="center">
			<h4>SMK Langit Biru Negeri</h4>
			<h5>Jl. Raya Majalaya - Rancaekek Desa No.5, Bojongloa, Kec. Rancaekek, Bandung, Jawa Barat 40394</h5>
			<h6>No.Telp: 089656428386</h6>
		</div>
	</div>
</div>

<div class="container">
	<div class="col-md-3 col-xs-12 menu-sidebar">
		<hr>
		<?php
			echo date('h : i : s a');	
			echo "</br>";
			echo date('l, d-M-Y');
		?>
		<hr>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="profil.php">Profil</a></li>
			<li><a href="galeri.php">Galeri</a></li>
			<li><a href="javascipt.php">javascript</li>
			<li><a href="upload_file.php">Upload File</a></li>
			<li><a href="login.php">Login</li><a>
			<li><a href="logout.php">LOGOUT</a></li>
		</ul>

		<h5 align="center">About</h5>
		<p><strong>SMK Langit Biru Negeri </strong>adalah sekolah berbasis seperti
			sekolah di Jepang yang dimana sekolah ini mengikuti peraturan-peraturan yang
			ada di sekolah di Jepang,
		</p>
	</div>
</div>

<div class="container">
	<div class="content">
		<h3>Mengubah kalimat ke Uppercase dan Lowercase</h3>
		<p>Masukkan Kalimat</p>
		<input type="text" name="txtnama" id="txtnama" size="20">
		<input type="button" name="btnTest" value="Uppercase" onclick="uppercase();">
			<script type="text/javascript">
				document.write("Hasil Tampilan: </br>"+textcontrol.toUpperCase()+"</br>");
			</script>
	</div>
</div>
</body>
</html>
<?php
session_start();
if(!isset($_SESSION['username'])) {
    header('location:login.php'); 
} else { 
    $username = $_SESSION['username']; 
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>SMK Langit Biru Negeri</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-widht, initial-scale=1.0">
	<script type="text/javascript">
    function pesan(){
    	alert("Login Sukses");
    }
	</script>
</head>
<body onload="pesan();">
<div class="container">
	<div class="header">
		<img src="img/jepang/logo_sakura.png" width="9%" style="float: left;">
		<div class="container" align="center">
			<h4>SMK Langit Biru Negeri</h4>
			<h5>Jl. Raya Majalaya - Rancaekek Desa No.5, Bojongloa, Kec. Rancaekek, Bandung, Jawa Barat 40394</h5>
			<h6>No.Telp: 089656428386</h6>
		</div>
	</div>
</div>

<div class="container">
	<div class="col-md-3 col-xs-12 menu-sidebar">
		<hr>
		<?php
			echo date('h : i : s a');	
			echo "</br>";
			echo date('l, d-M-Y');
		?>
		<hr>
		<ul>
			<li><a href="index.php">Home</a></li>
			<li><a href="profil.php">Profil</a></li>
			<li><a href="galeri.php">Galeri</a></li>
			<li><a href="upload_file.php">Upload File</a></li>
			<li><a href="login.php">Login</li><a>
			<li><a href="logout.php">LOGOUT</a></li>
		</ul>

		<h5 align="center">About</h5>
		<p><strong>SMK Langit Biru Negeri </strong>adalah sekolah berbasis seperti
			sekolah di Jepang yang dimana sekolah ini mengikuti peraturan-peraturan yang
			ada di sekolah di Jepang,
		</p>
	</div>
</div>

<div class="container">
	<div class="content">
		<div align='center'>
           Selamat Datang, <b><?php echo $username;?></b>\
        </div>
		<div class=malasngoding-slider>
		    <div class=isi-slider>
		      	<img src="img/jepang/jp3.jpg" alt="Gambar 1">
		      	<img src="img/jepang/jp1.jpg" alt="Gambar 1">
		      	<img src="img/jepang/jp11.jpg" alt="Gambar 1">
		    </div>
		</div>
		<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
	</div>
</div>

<div class="container">
	<div class="footer">
		<div class="container" align="center">
			<h4>Copyright &copy; 2019</h4>
			<p>mikhsanassidiq54@gmail.com</p>
			<p>Web ini dibuat oleh Muhamad Ikhsan Assidiq</p>
		</div>
	</div>
</div>

</body>
</html>